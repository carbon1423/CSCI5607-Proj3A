
//Set the global scene parameter variables
//TODO: Set the scene parameters based on the values in the scene file

#ifndef PARSE_VEC3_H
#define PARSE_VEC3_H

#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>
#include <sstream>
#include <vector>

//Camera & Scene Parameters (Global Variables)
//Here we set default values, override them in parseSceneFile()
struct Material {
    vec3 ka; 
    vec3 kd; 
    vec3 ks; 
    vec3 kt; 
    float shininess; 
    float ior;        
    Material(vec3 a, vec3 d, vec3 s, vec3 t, float shine, float i) : ka(a), kd(d), ks(s), kt(t), shininess(shine), ior(i) {}
};
struct Sphere {
  vec3 pos;
  float rad;
  Material mat;
  Sphere(vec3 p, float r, Material m) : pos(p), rad(r), mat(m){}
};

struct PointLight {
  vec3 pos;
  vec3 col;

  PointLight(vec3 p, vec3 c) : pos(p), col(c) {}
};



//Image Parameters
int img_width = 800, img_height = 600;
std::string imgName = "raytraced.png";

//Camera Parameters
vec3 eye = vec3(0,0,0); 
vec3 forward = vec3(0,0,-1).normalized();
vec3 up = vec3(0,1,0).normalized();
vec3 right;
float halfAngleVFOV = 35; 

//Scene (Sphere) Parameters
std::vector<Sphere> spheres;

//Lighting 
std::vector<PointLight> point_lights;
vec3 ambientLight = vec3(0,0,0);

//Background
vec3 backgroundColor = vec3(0,0,0);

int max_depth = 5;

void parseSceneFile(std::string fileName){
  //TODO: Override the default values with new data from the file "fileName"
  std::ifstream file(fileName);
  std::string line;
  Material currentMaterial(
        vec3(0,0,0), vec3(1,1,1), vec3(0,0,0), vec3(0,0,0), 5.0f, 1.0f
        );
  while (getline(file, line)){
    std::string chunk;
    std::stringstream ss(line);
    while(ss >> chunk){
      if(chunk.compare("material:") == 0){
        float ar, ag, ab,
              dr, dg, db,
              sr, sg, sb, ns,
              tr, tg, tb, ior;
        ss >> ar >> ag >> ab >> 
              dr >> dg >> db >> 
              sr >> sg >> sb >> ns >>
              tr >> tg >> tb >> ior;
        currentMaterial = Material(vec3(ar,ag,ab), 
                            vec3(dr,dg,db), 
                            vec3(sr,sg,sb),
                            vec3(tr,tg,tb), ns, ior);
      }
      if(chunk.compare("sphere:") == 0){
        float x,y,z,r; 
        ss >> x >> y >> z >> r;
        spheres.push_back(Sphere(vec3(x,y,z), r, currentMaterial));
      }
      
      if(chunk.compare("image_resolution:") == 0){
        int w,h;
        ss >> w >> h;
        img_width = w;
        img_height = h;
      }
      if(chunk.compare("output_image:") == 0){
        std::string outName;
        ss >> outName;
        imgName = outName;
      }
      if(chunk.compare("camera_pos:") == 0){
        float x,y,z;
        ss >> x >> y >> z;
        eye = vec3(x,y,z);
      }
      if(chunk.compare("camera_up:") == 0){
        float ux, uy, uz;
        ss >> ux >> uy >> uz;
        up = vec3(ux, uy, uz);
      }
      if(chunk.compare("camera_fwd:") == 0){
        float fx, fy, fz;
        ss >> fx >> fy >> fz;
        forward = vec3(fx, fy, fz);
      }
      if(chunk.compare("camera_fov_ha:") == 0){
        float ha;
        ss >> ha;
        halfAngleVFOV = ha;
      }
      if(chunk.compare("background:") == 0){
        float r, g, b;
        ss >> r >> g >> b;
        backgroundColor = vec3(r,g,b);
      }
      if(chunk.compare("point_light:") == 0){
        float r, g, b, x, y, z;
        ss >> r >> g >> b >> x >> y >> z;
        vec3 lightColor = vec3(r,g,b);
        vec3 lightPos = vec3(x,y,z);
        point_lights.push_back(PointLight(lightPos, lightColor));

      }
      if(chunk.compare("ambient_light:") == 0){
        float r, g, b;
        ss >> r >> g >> b;
        ambientLight = vec3(r,g,b);
      }
      if(chunk.compare("max_depth") == 0){
        int n;
        ss >> n;
        max_depth = n;
      }
    }
  }

  right = cross(up, forward);
  //TODO: Create an orthogonal camera basis, based on the provided up and right vectors
  // printf("Orthogonal Camera Basis:\n");
  // printf("forward: %f,%f,%f\n",forward.x,forward.y,forward.z);
  // printf("right: %f,%f,%f\n",right.x,right.y,right.z);
  // printf("up: %f,%f,%f\n",up.x,up.y,up.z);
}

#endif