#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS // For fopen and sscanf
#define _USE_MATH_DEFINES 
#endif

//Images Lib includes:
#define STB_IMAGE_IMPLEMENTATION //only place once in one .cpp file
#define STB_IMAGE_WRITE_IMPLEMENTATION //only place once in one .cpp files
#include "image_lib.h" //Defines an image class and a color class

//#Vec3 Library
#include "vec3.h"

//High resolution timer
#include <chrono>

#include <iomanip>

//Scene file parser
#include "parse_vec3.h"


bool raySphereIntersect(vec3 start, vec3 dir, vec3 center, float radius, float &tHit){
  float a = dot(dir,dir); //TODO - Understand: What do we know about "a" if "dir" is normalized on creation?
  vec3 toStart = (start - center);
  float b = 2 * dot(dir,toStart);
  float c = dot(toStart,toStart) - radius*radius;
  float discr = b*b - 4*a*c;
  if (discr < 0) return false;
  float sqrtDiscr = sqrt(discr);
  float t0 = (-b - sqrtDiscr) / (2 * a);
  float t1 = (-b + sqrtDiscr) / (2 * a);
  
  if (t0 > 0 && t1 > 0) tHit = std::min(t0, t1);
  else if (t0 > 0) tHit = t0;
  else if (t1 > 0) tHit = t1;
  else return false;
  return true;
}

vec3 rayTrace(vec3 start, vec3 dir, int depth=5){
	if (depth <= 0) {
	    return backgroundColor;
	}
	float closestT = std::numeric_limits<float>::max();
    int hitSphereIndex = -1;
    
    for (int s = 0; s < spheres.size(); s++) {
        float tHit;
        if (raySphereIntersect(start, dir, spheres[s].pos, spheres[s].rad, tHit)) {
            if (tHit < closestT) {
                closestT = tHit;
                hitSphereIndex = s;
            }
        }
    }

      if (hitSphereIndex != -1){
        Sphere &sphere = spheres[hitSphereIndex];
        // Material &material = materials[hitSphereIndex];

        vec3 hitPoint = start + closestT*dir;
        vec3 normal = (hitPoint - sphere.pos).normalized();

        vec3 Ia = sphere.mat.ka * ambientLight;
        vec3 Id(0, 0, 0);
        vec3 Is(0, 0, 0);
        vec3 V = (start - hitPoint).normalized();

        
        for (const auto& light : point_lights) {
            vec3 L = (light.pos - hitPoint).normalized();
            float lightDist = (light.pos - hitPoint).length();
        
            // Shadow test
            bool inShadow = false;
            for (int s = 0; s < spheres.size(); s++) {
                float tHit;
                if (raySphereIntersect(hitPoint + 1e-4f * L, L, spheres[s].pos, spheres[s].rad, tHit)) {
                    if (tHit < lightDist) {
                        inShadow = true;
                        break;
                    }
                }
            }
        
            if (!inShadow) {
                float attenuation = 1.0f / (lightDist * lightDist);
                vec3 R = (2.0f * dot(normal, L) * normal - L).normalized();
                Id += attenuation * std::max(0.0f, dot(normal, L)) * light.col * sphere.mat.kd;
                Is += attenuation * std::pow(std::max(0.0f, dot(R, V)), sphere.mat.shininess) * light.col * sphere.mat.ks;
            }
        }

        vec3 c = Ia + Id + Is;
        vec3 reflectionColor(0, 0, 0);
		if (depth > 0) {
		    vec3 reflectDir = (dir - (2.0f * dot(dir, normal) * normal) ).normalized();
		    reflectionColor = rayTrace(hitPoint + 1e-4f * reflectDir, reflectDir, depth - 1);
		}
		vec3 reflect =  sphere.mat.ks * reflectionColor;
        

        // vec3 refractionColor(0,0,0);
        // bool didTIR = false;
        // if(sphere.mat.kt.length() > 0.0f){
        //     vec3 N = normal;
        //     float eta;
        //     float cosi = dot(dir, normal);
        //     bool entering = cosi < 0;
        //     if(entering){
        //         eta = 1.0f / sphere.mat.ior;
        //         cosi = -cosi;
        //     }else {
        //         eta = sphere.mat.ior;
        //         N = -1 * N;
        //     }

        //     float k = 1.0f - eta * eta * (1.0f - cosi * cosi);
        //     if(k >= 0.0f){
        //         vec3 refractDir = (eta * dir + (eta * cosi - std::sqrt(k)) * N).normalized();
        //         refractionColor = rayTrace(hitPoint + 1e-4f * refractDir, refractDir, depth -1);
        //     }else {
        //         didTIR = true;
        //         refractionColor = reflectionColor;
        //     }
        // }

        // vec3 refract = sphere.mat.kt * refractionColor;
        // vec3 ks = sphere.mat.ks;
        // vec3 kt = sphere.mat.kt;
        // if (didTIR) {
        //     ks = ks + kt;
        //     kt = vec3(0.0f,0.0f,0.0f);
        // }

        // vec3 c_final = (vec3(1.0f,1.0f,1.0f) - sphere.mat.ks - sphere.mat.kt).clampTo1() * c + reflect + refract;
        vec3 c_final = (vec3(1.0f,1.0f,1.0f) - sphere.mat.ks).clampTo1() * c + reflect;

        vec3 c_clamped = c_final.clampTo1();

        return c_clamped;
    }else {
        return backgroundColor;
    }
}

int main(int argc, char** argv){

  //Read command line paramaters to get scene file
  if (argc != 2){
     std::cout << "Usage: ./ray scenefile\n";
     return(0);
  }
  std::string sceneFileName = argv[1];

  //Parse Scene File
  parseSceneFile(sceneFileName);

  float imgW = img_width, imgH = img_height;
  float halfW = imgW/2, halfH = imgH/2;
  float d = halfH / tanf(halfAngleVFOV * (M_PI / 180.0f));

  Image outputImg = Image(img_width,img_height);
  auto t_start = std::chrono::high_resolution_clock::now();
  for (int i = 0; i < img_width; i++){
    // std::cout << "Percent remaining: "<< std::setprecision(2) << (float)(img_width-i)/(float)img_width << std::endl;
    float progress = (float)i / (float)img_width;
    int barWidth = 50;

    std::cout << "\r[";
    int pos = static_cast<int>(barWidth * progress);
    for (int j = 0; j < barWidth; ++j) {
        if (j < pos) std::cout << "#";
        else if (j == pos) std::cout << "#";
        else std::cout << " ";
    }
    std::cout << "] " << std::fixed << std::setprecision(1) << (progress * 100.0f) << "%";
    std::cout.flush();
    for (int j = 0; j < img_height; j++){
      float u = (halfW - (imgW)*((i+0.5)/imgW));
      float v = (halfH - (imgH)*((j+0.5)/imgH));
      vec3 p = eye - d*forward + u*right + v*up;
      vec3 rayDir = (p - eye).normalized(); 
	  vec3 c = rayTrace(eye, rayDir, max_depth);
	  Color color = Color(c.x,c.y,c.z);
	  outputImg.setPixel(i,j, color);
	  }
  }
    auto t_end = std::chrono::high_resolution_clock::now();
  std::cout << "\nRendering took "
          << std::fixed << std::setprecision(2)
          << std::chrono::duration<double, std::milli>(t_end - t_start).count()
          << " ms" << std::endl;
  outputImg.write(imgName.c_str());
  return 0;
}
